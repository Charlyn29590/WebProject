document.addEventListener('DOMContentLoaded', () => {
    
    // Dark Mode Toggle
    const themeToggle = document.getElementById('themeToggle');
    const html = document.documentElement;
    
    // Check for saved theme preference or default to light mode
    const currentTheme = localStorage.getItem('theme') || 'light';
    html.setAttribute('data-theme', currentTheme);
    
    // Theme toggle functionality
    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            const currentTheme = html.getAttribute('data-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            
            html.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
        });
    }
    
    // Mobile Navigation
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');
    
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('active');
            navMenu.classList.toggle('active');
            const isExpanded = navMenu.classList.contains('active');
            navToggle.setAttribute('aria-expanded', isExpanded);
        });
        
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('active');
                navMenu.classList.remove('active');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }
    
    // Smooth Scroll
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const headerOffset = 80;
                const elementPosition = target.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
                
                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Active Navigation Link
    const sections = document.querySelectorAll('section[id]');
    
    function updateActiveLink() {
        const scrollY = window.pageYOffset;
        
        sections.forEach(section => {
            const sectionHeight = section.offsetHeight;
            const sectionTop = section.offsetTop - 100;
            const sectionId = section.getAttribute('id');
            const navLink = document.querySelector(`.nav-link[href="#${sectionId}"]`);
            
            if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
                navLinks.forEach(link => link.classList.remove('active'));
                if (navLink) navLink.classList.add('active');
            }
        });
    }
    
    window.addEventListener('scroll', updateActiveLink);
    
    // Circular Progress Animation
    const skillBoxes = document.querySelectorAll('.skill-box');
    
    function animateSkills() {
        skillBoxes.forEach(box => {
            const circle = box.querySelector('.circle-progress');
            const percentText = box.querySelector('.percent-number');
            const percent = box.getAttribute('data-percent');
            
            if (!circle || !percent) return;
            
            const rect = box.getBoundingClientRect();
            const isVisible = rect.top < window.innerHeight && rect.bottom > 0;
            
            if (isVisible && !box.classList.contains('animated')) {
                box.classList.add('animated');
                
                // Animate circle
                const circumference = 2 * Math.PI * 45;
                const offset = circumference - (percent / 100) * circumference;
                
                setTimeout(() => {
                    circle.style.strokeDashoffset = offset;
                }, 200);
                
                // Animate number
                let current = 0;
                const increment = percent / 30;
                const timer = setInterval(() => {
                    current += increment;
                    if (current >= percent) {
                        current = percent;
                        clearInterval(timer);
                    }
                    percentText.textContent = Math.floor(current);
                }, 50);
            }
        });
    }
    
    window.addEventListener('scroll', animateSkills);
    animateSkills();
    
    // Scroll Reveal
    const revealElements = document.querySelectorAll('.section-header, .about-wrapper, .skills-content, .timeline-wrapper, .projects-grid, .contact-wrapper, .resume-simple');
    
    function reveal() {
        revealElements.forEach(element => {
            const windowHeight = window.innerHeight;
            const elementTop = element.getBoundingClientRect().top;
            const revealPoint = 150;
            
            if (elementTop < windowHeight - revealPoint) {
                element.style.opacity = '1';
                element.style.transform = 'translateY(0)';
            }
        });
    }
    
    revealElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'all 0.8s ease';
    });
    
    window.addEventListener('scroll', reveal);
    reveal();
    
    // Form Validation
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const subject = document.getElementById('subject').value.trim();
            const message = document.getElementById('message').value.trim();
            
            if (!name || !email || !message) {
                alert('Please fill in all required fields');
                return;
            }
            
            if (!email.includes('@') || !email.includes('.')) {
                alert('Please enter a valid email address');
                return;
            }
            
            alert('Thank you for your message! I will get back to you soon.');
            contactForm.reset();
        });
    }
    
    // Resume Download - Simple confirmation for direct link
    const downloadBtn = document.getElementById('downloadResume');
    
    if (downloadBtn) {
        downloadBtn.addEventListener('click', (e) => {
            // The actual download happens via the href attribute
            // This just shows a confirmation message
            setTimeout(() => {
                alert('Resume download started! Check your assets folder.');
            }, 500);
        });
    }
    
    // Enhanced scroll effects for sections
    const sectionsWithEffects = document.querySelectorAll('section');
    
    function addScrollEffects() {
        const scrollY = window.pageYOffset;
        
        sectionsWithEffects.forEach(section => {
            const rect = section.getBoundingClientRect();
            const isVisible = rect.top < window.innerHeight && rect.bottom > 0;
            
            if (isVisible) {
                // Add parallax effect to floating gradients
                const beforeElement = section.querySelector('::before');
                if (beforeElement) {
                    const speed = 0.5;
                    const yPos = -(scrollY * speed);
                    // Note: CSS pseudo-elements can't be directly manipulated with JS
                    // This is handled by CSS animations instead
                }
            }
        });
    }
    
    window.addEventListener('scroll', addScrollEffects);
    
    // Navbar scroll effect
    const navbar = document.querySelector('.navbar');
    
    function updateNavbar() {
        if (window.scrollY > 100) {
            navbar.style.background = html.getAttribute('data-theme') === 'dark' 
                ? 'rgba(12, 10, 9, 0.98)' 
                : 'rgba(255, 245, 240, 0.98)';
            navbar.style.backdropFilter = 'blur(12px)';
            navbar.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.1)';
        } else {
            navbar.style.background = html.getAttribute('data-theme') === 'dark' 
                ? 'rgba(12, 10, 9, 0.95)' 
                : 'rgba(255, 245, 240, 0.95)';
            navbar.style.backdropFilter = 'blur(10px)';
            navbar.style.boxShadow = 'none';
        }
    }
    
    window.addEventListener('scroll', updateNavbar);
    updateNavbar();
    
    // Update navbar background on theme change
    const observer = new MutationObserver(() => {
        updateNavbar();
    });
    
    observer.observe(html, {
        attributes: true,
        attributeFilter: ['data-theme']
    });
    
    console.log('Charlyn Montenegro Portfolio Loaded');
});
